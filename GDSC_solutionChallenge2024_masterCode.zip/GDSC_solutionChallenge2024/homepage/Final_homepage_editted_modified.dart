import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome to Our App'),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: EdgeInsets.all(20),
              color: Colors.orange,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Introduction',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  // Add introduction content here (texts and pictures)
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(20),
              color: Colors.orange[300],
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Fight Communicable Diseases and Mental Health',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Here, you can find the information on communicable diseases as well as prevention tips, and mental health resources as well.',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white, // Increased font size for sub-section text
                    ),
                  ),
                  SizedBox(height: 20),
                  // Grid-style subsections
                  buildSubSectionsGrid(context, [
                    'Information on Communicable Diseases',
                    'Prevention Tips and Healthy Lifestyle Resources',
                    'Mental Health Resources and Support',
                    'Stress Reduction Techniques',
                  ]),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(20),
              color: Colors.green,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Road Safety',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'The below features will help you to avoid getting stuck in traffic congestion as well as to prevent being a victim of road accidents. In case of an unfortunate accident, this section will help you to find hospitals near you and navigate to the nearest hospital to you in case of an emergency.',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white, // Increased font size for sub-section text
                    ),
                  ),
                  SizedBox(height: 20),
                  // Grid-style subsections
                  buildSubSectionsGrid(context, [
                    'Nearest Hospitals',
                    'Nearest Hospital Route',
                    'Weather Status',
                    'School Zones',
                    'Traffic Alert',
                    'Safe Driving Tips and Awareness Campaigns',
                    'Information on Sustainable Transportation and Promoting Public Transportation and Walking/Cycling',
                  ]),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(20),
              color: Colors.blue,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Pollution and Chemical Safety',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'This section will help you to stay alert of the pollution level in your area, and will display the probable polluted areas near industrial sites, and also show green areas which are essentially non-polluted regions where one can visit to stay away from pollution for a while as well as for recreational purposes. This section would also help users affiliated with chemical industries for handling hazardous chemicals as well as make the users aware of chemical safety. It would also guide the users in case of an emergency chemical spill and help them find nearby hospitals which could save a user\'s life.',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white, // Increased font size for sub-section text
                    ),
                  ),
                  SizedBox(height: 20),
                  // Grid-style subsections
                  buildSubSectionsGrid(context, [
                    'Air Quality Index Mapping',
                    'Chemical Factory Marking',
                    'Emergency Service Locator',
                    'Green Spaces',
                    'Industrial Areas',
                    'Nearest Hospitals',
                    'Nearest Hospitals Route',
                    'Tips for Reducing Personal Environmental Impact',
                    'Guidelines for Handling Hazardous Chemicals',
                    'Resources for Chemical Safety Education',
                  ]),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(20),
              color: Colors.purple,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Chatbot',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'This Dr. Chatbot will help you to solve your health issues after discussing your symptoms. Go ahead and resolve your health issues.',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white, // Increased font size for sub-section text
                    ),
                  ),
                  SizedBox(height: 20),
                  // Grid-style subsections
                  buildSubSectionsGrid(context, [
                    'Dr. Chatbot',
                  ]),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(20),
              color: Colors.green[300],
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Conclusion',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  // Add conclusion content here
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(20),
              color: Colors.grey[200],
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Contact and Support',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Your contact and support information goes here...',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(20),
              color: Colors.grey[200],
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'About Us',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Your about us text goes here...',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Method to build grid-style subsections
  Widget buildSubSectionsGrid(BuildContext context, List<String> subSections) {
    return GridView.count(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      children: subSections.map((String subSection) {
        return ElevatedButton(
          onPressed: () {
            // Handle navigation to selected sub-section
            handleNavigation(context, subSection);
          },
          child: Text(subSection),
        );
      }).toList(),
    );
  }

  // Method to handle navigation based on selected sub-section
  void handleNavigation(BuildContext context, String selectedSubSection) {
    // Implement navigation logic based on the selected sub-section
    switch (selectedSubSection) {
      case 'Information on Communicable Diseases':
        // Navigate to PDF file or Dart program for Information on Communicable Diseases
        break;
      case 'Prevention Tips and Healthy Lifestyle Resources':
        // Navigate to PDF file or Dart program for Prevention Tips and Healthy Lifestyle Resources
        break;
      case 'Mental Health Resources and Support':
        // Navigate to PDF file or Dart program for Mental Health Resources and Support
        break;
      case 'Stress Reduction Techniques':
        // Navigate to PDF file or Dart program for Stress Reduction Techniques
        break;
      // Add more cases for other sub-sections as needed
      case 'Nearest Hospitals':
        // Navigate to Dart program for Nearest Hospitals
        break;
      case 'Nearest Hospital Route':
        // Navigate to Dart program for Nearest Hospital Route
        break;
      case 'Weather Status':
        // Navigate to Dart program for Weather Status
        break;
      case 'School Zones':
        // Navigate to Dart program for School Zones
        break;
      case 'Traffic Alert':
        // Navigate to Dart program for Traffic Alert
        break;
      case 'Safe Driving Tips and Awareness Campaigns':
        // Navigate to PDF file or Dart program for Safe Driving Tips and Awareness Campaigns
        break;
      case 'Information on Sustainable Transportation and Promoting Public Transportation and Walking/Cycling':
        // Navigate to PDF file or Dart program for Information on Sustainable Transportation
        break;
      // Add more cases for other sub-sections as needed
    }
  }
}
