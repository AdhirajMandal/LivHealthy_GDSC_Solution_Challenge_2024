// To navigate between different Dart files when the user presses buttons or subsections in the navigation menu, you can use Flutter's built-in navigation system along with routes.

//Here's how you can set up navigation to open other designated Dart files:

//Define routes for each of your Dart files in the MaterialApp widget.
//Use the Navigator widget or Navigator.push method to navigate to the designated Dart file when a button or subsection is pressed.
//First, define your routes in the MaterialApp widget:
MaterialApp(
  title: 'Hospital Locator',
  theme: ThemeData(
    primarySwatch: Colors.blue,
  ),
  initialRoute: '/',
  routes: {
    '/': (context) => HospitalLocatorPage(),
    '/other_page': (context) => OtherPage(), // Example route to other page
    // Add more routes for other Dart files as needed
  },
);
//Then, in your Dart file where you have buttons or subsections in the navigation menu, use Navigator.pushNamed to navigate to the designated Dart file:
ElevatedButton(
  onPressed: () {
    Navigator.pushNamed(context, '/other_page'); // Navigate to OtherPage
  },
  child: Text('Go to Other Page'),
),
//Replace 'other_page' with the route name of the Dart file you want to navigate to. You can define multiple routes for different Dart files in the MaterialApp, and each route should correspond to a specific Dart file.

//Make sure that the designated Dart file (e.g., OtherPage) is imported and implemented correctly.