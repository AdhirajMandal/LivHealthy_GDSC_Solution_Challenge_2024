import 'package:http/http.dart' as http;
import 'dart:convert';

// Inside the LoginForm widget
ElevatedButton(
  onPressed: () async {
    // Make HTTP POST request to backend
    var url = Uri.parse('http://your-backend-url/login');
    var response = await http.post(
      url,
      body: jsonEncode({'email': email, 'password': password}),
      headers: {'Content-Type': 'application/json'},
    );

    // Process response
    if (response.statusCode == 200) {
      var responseData = jsonDecode(response.body);
      if (responseData['success']) {
        // Login successful, navigate to homepage
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => HomePage()),
        );
      } else {
        // Login failed, display error message
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Login Failed'),
              content: Text(responseData['message']),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('OK'),
                ),
              ],
            );
          },
        );
      }
    } else {
      // Handle server error
      print('Error: ${response.statusCode}');
    }
  },
  child: Text('Login'),
)
