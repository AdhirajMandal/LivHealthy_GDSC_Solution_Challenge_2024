// Inside the onPressed function of the ElevatedButton
Navigator.push(
  context,
  MaterialPageRoute(builder: (context) => HomePage()),
);
