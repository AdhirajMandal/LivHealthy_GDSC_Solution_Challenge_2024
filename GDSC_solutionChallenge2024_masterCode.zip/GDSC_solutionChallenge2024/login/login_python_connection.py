# -*- coding: utf-8 -*-
"""
Created on Tue Feb 13 14:34:28 2024

@author: adhir
"""

# Example Flask endpoint for handling login requests
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/login', methods=['POST'])
def login():
    # Get login credentials from request body
    data = request.json
    email = data.get('email')
    password = data.get('password')

    # Perform authentication (replace with your authentication logic)
    if email == 'example@email.com' and password == 'password':
        return jsonify({'success': True, 'message': 'Login successful'})
    else:
        return jsonify({'success': False, 'message': 'Invalid email or password'})

if __name__ == '__main__':
    app.run(debug=True)
