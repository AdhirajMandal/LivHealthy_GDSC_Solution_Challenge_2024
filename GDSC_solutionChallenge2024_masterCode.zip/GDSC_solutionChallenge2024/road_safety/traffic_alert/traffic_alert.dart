import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final String _apiKey = 'YOUR_API_KEY_HERE'; // Replace with your Google API key

  Future<void> _fetchDataAndShowAlert(BuildContext context) async {
    try {
      final response = await http.get(Uri.parse('https://ipinfo.io/json'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final loc = data['loc'] as String;
        final lat = double.parse(loc.split(',')[0]);
        final lng = double.parse(loc.split(',')[1]);

        final accidentProneZone = await checkAccidentProneZone(lat, lng);
        final trafficJam = await checkTrafficJam(lat, lng);

        if (accidentProneZone) {
          _showAlert(context, 'You are in an accident-prone zone!');
        }

        if (trafficJam) {
          _showAlert(context, 'You are near a heavy traffic jam!');
        }
      } else {
        print('Error: Unable to fetch location. Status Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  Future<bool> checkAccidentProneZone(double lat, double lng) async {
    // Implement logic to check accident-prone zone
    return false;
  }

  Future<bool> checkTrafficJam(double lat, double lng) async {
    // Implement logic to check traffic jam
    return false;
  }

  void _showAlert(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Traffic Alert'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Traffic Alert App',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Traffic Alert App'),
        ),
        body: Center(
          child: ElevatedButton(
            onPressed: () => _fetchDataAndShowAlert(context),
            child: Text('Check Traffic Alerts'),
          ),
        ),
      ),
    );
  }
}
